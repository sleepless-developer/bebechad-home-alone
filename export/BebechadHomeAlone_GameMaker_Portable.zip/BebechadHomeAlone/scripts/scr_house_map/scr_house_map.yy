{
  "$GMScript": "v1",
  "%Name": "scr_house_map",
  "isCompatibility": false,
  "isDnD": false,
  "name": "scr_house_map",
  "parent": {
    "name": "Scripts",
    "path": "folders/Scripts.yy"
  },
  "resourceType": "GMScript",
  "resourceVersion": "2.0"
}
